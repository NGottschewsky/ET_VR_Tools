This is the free package "Workplace Tools" by ikapoura. 

The content provided is free and you can use them and modify them freely in your projects. 
This project aims to provide a fast prototyping experience by providing some simple but 
detailed models to get you going.

- How to use the package

Simply drag and drop any model you want from the Prefabs folder into your scene and you are ready!

- Materials

The materials are simple colors and every model has it's own materials named after it. This will
help altering only the color of one model to avoid confusion. (Except bolts. Bolts are mean.)

- Colliders

I have pre-enabled the Mesh Colliders for every objects and set Convex to true. If you want physics
interactions, simply add a Rigidbody Component to the root GameObject of each prefab.

- Help / questions

For any help, questions or even suggestions please email me at:

kapouranis.ilias@gmail.com

Enjoy!